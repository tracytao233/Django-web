from django.shortcuts import render, redirect 
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group
from .models import *
from .forms import HwkForm, CreateUserForm, StudentForm
from .filters import HwkFilter
from .decorators import unauthenticated_user, allowed_users, admin_only
# Create your views here.

@unauthenticated_user
def registerPage(request):
	form = CreateUserForm()
	if request.method == 'POST' :
		form = CreateUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			username = form.cleaned_data.get('username')
			messages.success(request, 'Account was created for ' + username)
			resp.set_cookie("username", username)
			return redirect('login')
		

	context = {'form':form}
	return render(request, 'user/register.html', context)


@unauthenticated_user
def loginPage(request):

	if request.method == 'POST':
		username = request.POST.get('username')
		password =request.POST.get('password')

		user = authenticate(request, username=username, password=password)

		if user is not None:
			login(request, user)
			return redirect('home')
		else:
			messages.info(request, 'Username OR password is incorrect')

	context = {}
	return render(request, 'user/login.html', context)

def logoutUser(request):
	logout(request)
	return redirect('login')

@login_required(login_url='login')
@admin_only
def home(request):
	orders = Order.objects.all()
	students = Student.objects.all()

	total_Students = students.count()

	total_hwks = hwks.count()
	finished = hwks.filter(status='Finished').count()
	ongoing = hwks.filter(status='Ongoing').count()

	context = {'hwks':hwks, 'students':students,
	'total_hwks':total_hwks,'finished':finished,
	'ongoing':ongoing }

	return render(request, 'user/dashboard.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['student'])
def userPage(request):
	hwks = request.user.student.hwk_set.all()

	total_hwks = hwks.count()
	finished = hwks.filter(status='Finished').count()
	ongoing = hwks.filter(status='Ongoing').count()

	print('HWKS:', hwks)

	context = {'hwks':hwks, 'total_hwks':total_hwks,
	'finished':finished,'ongoing':ongoing}
	return render(request, 'user/user.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['student'])
def accountSettings(request):
	student = request.user.student
	form = StudentForm(instance=student)

	if request.method == 'POST':
		form = StudentForm(request.POST, request.FILES,instance=student)
		if form.is_valid():
			form.save()


	context = {'form':form}
	return render(request, 'user/account_settings.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def homeworks(request):
	homeworks = Hmework.objects.all()

	return render(request, 'user/homeworks.html', {'homeworks':homeworks})

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def student(request, pk_test):
	student = Student.objects.get(id=pk_test)

	hwks = student.hwk_set.all()
	hwk_count = hwks.count()

	myFilter = OrderFilter(request.GET, queryset=orders)
	orders = myFilter.qs 

	context = {'student':student, 'hwks':hwks, 'hwk_count':hwk_count,
	'myFilter':myFilter}
	return render(request, 'user/student.html',context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createHwk(request, pk):
	HwkFormSet = inlineformset_factory(Student, Hwk, fields=('homework', 'status'), extra=10 )
	student = Student.objects.get(id=pk)
	formset = HwkFormSet(queryset=Hwk.objects.none(),instance=student)
	if request.method == 'POST':
		form = HwkForm(request.POST)
		formset = HwkFormSet(request.POST, instance=customer)
		if formset.is_valid():
			formset.save()
			return redirect('/')

	context = {'form':formset}
	return render(request, 'user/hwk_form.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateHwk(request, pk):
	hwk = Hwk.objects.get(id=pk)
	form = HwkForm(instance=hwk)
	print('HWK:', hwk)
	if request.method == 'POST':

		form = HwkForm(request.POST, instance=hwk)
		if form.is_valid():
			form.save()
			return redirect('/')

	context = {'form':form}
	return render(request, 'user/hwk_form.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteHwk(request, pk):
	hwk = Hwk.objects.get(id=pk)
	if request.method == "POST":
		hwk.delete()
		return redirect('/')

	context = {'item':hwk}
	return render(request, 'user/delete.html', context)