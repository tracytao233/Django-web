
# file: user/urls.py

from django.urls import path

from . import views

urlpatterns = [
	path('register/', views.registerPage, name="register"),
	path('login/', views.loginPage, name="login"),  
	path('logout/', views.logoutUser, name="logout"),

    path('', views.home, name="home"),
    path('user/', views.userPage, name="user-page"),

    path('account/', views.accountSettings, name="account"),

    path('homeworks/', views.homeworks, name='homeworks'),
    path('student/<str:pk_test>/', views.student, name="student"),

    path('create_hwk/<str:pk>/', views.createHwk, name="create_hwk"),
    path('update_hwk/<str:pk>/', views.updateHwk, name="update_hwk"),
    path('delete_hwk/<str:pk>/', views.deleteHwk, name="delete_hwk"),


]